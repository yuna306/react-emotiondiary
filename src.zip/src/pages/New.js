const New = () => {
  return (
    <div>
      <h1>New</h1>
      <p>이곳은 일기 작성페이지 입니다</p>
    </div>
  );
};

export default New;
