const Edit = () => {
  return (
    <div>
      <h1>Edit</h1>
      <p>이곳은 수정 페이지 입니다</p>
    </div>
  );
};

export default Edit;
