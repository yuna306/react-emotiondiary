const Home = () => {
  return (
    <div>
      <h1>Home</h1>
      <p>이곳은 홈 입니다</p>
    </div>
  );
};

export default Home;
