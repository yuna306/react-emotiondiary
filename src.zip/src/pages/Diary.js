const Diary = () => {
  return (
    <div>
      <h1>Diary</h1>
      <p>이곳은 다이어리 상세 입니다</p>
    </div>
  );
};

export default Diary;
